import React from "react";

function Info(){
  return(
 <div className="note">
   <h1>JavaScript & React js Bootcamp</h1>
   <p>JavaScript And React js web Dev BootCamp</p>
   </div>
  );
}

export default Info;