import React from "react";

function Footer(){
  return(
 <footer>
   <p>Copyright by BakhtawarShahid @ 2021{new Date().getFullYear()}
     </p>
   </footer>
  );
}

export default Footer;